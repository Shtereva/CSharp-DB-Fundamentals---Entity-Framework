﻿namespace P01_HospitalDatabase.Data
{
    public class Configuration
    {
        public const string ConnectionString = @"Server=.;Database=HospitalDatabase;Integrated Security=True";
    }
}
